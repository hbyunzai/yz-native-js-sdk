var BaseDevice = /** @class */ (function () {
    function BaseDevice(option) {
        this.option = option;
    }
    return BaseDevice;
}());
export { BaseDevice };
//# sourceMappingURL=base.device.js.map