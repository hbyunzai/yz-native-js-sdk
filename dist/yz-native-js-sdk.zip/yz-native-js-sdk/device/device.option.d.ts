export interface DeviceOption {
    GATE_WAY?: string;
    TOKEN_TYPE?: string;
    TOKEN_VALUE?: string;
}
