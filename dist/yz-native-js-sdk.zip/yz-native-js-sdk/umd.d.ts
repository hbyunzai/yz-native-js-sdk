import { PlatForm } from "./device/platform";
export default PlatForm;
