export declare const http: (method: "GET" | "POST", url: string, success: (response: any) => void, options?: any) => void;
