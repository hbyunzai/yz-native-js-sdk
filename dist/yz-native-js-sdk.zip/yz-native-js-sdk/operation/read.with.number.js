/**
 * 读物时间打开方式枚举类型
 */
export var YzReadWithNumberOpenType;
(function (YzReadWithNumberOpenType) {
    YzReadWithNumberOpenType["PDF"] = "pdf";
    YzReadWithNumberOpenType["WEB"] = "web";
})(YzReadWithNumberOpenType || (YzReadWithNumberOpenType = {}));
//# sourceMappingURL=read.with.number.js.map